// Stub file - Google Cloud signin backup removed, using AWS instead
export type SigninDataRecord = any;
export function createGoogleCloudSigninBackupService() {
  return {};
}
