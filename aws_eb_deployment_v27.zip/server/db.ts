import * as schema from "@shared/schema";

export const pool = null;
export const db = null;
